"""dashboard.py - turns analysis results into a readable text dashboard."""
from datetime import date
import analysis

ARROW = {"rise": "▲ (spending UP)", "fall": "▼ (spending DOWN)", "flat": "• (no change)"}


def bar(percent, width=30):
    filled = min(int(percent / 100 * width), width)
    return "[" + "#" * filled + "-" * (width - filled) + f"] {percent:5.1f}%"


def render(data, today=None):
    today = today or date.today()
    s = analysis.budget_status(data, today)
    lines = ["=" * 56, f"  PERSONAL FINANCE DASHBOARD - {today:%B %Y}", "=" * 56]

    lines += [
        f"Monthly budget : {s['budget']:>10,.2f}",
        f"Spent so far   : {s['spent']:>10,.2f}",
        f"Remaining      : {s['remaining']:>10,.2f}",
        bar(s["percent_used"]),
        f"Safe to spend per day from today: {s['safe_per_day']:,.2f}",
        f"Projected month-end spend       : {s['projected']:,.2f}",
    ]
    if s["over_budget"]:
        lines.append("!! You are OVER budget this month.")
    elif s["projected"] > s["budget"] > 0:
        lines.append("! At this pace you will exceed your budget.")

    lines += ["", "WEEKLY SPENDING (Mon-Sun)", "-" * 56]
    for monday, total, diff, pct, trend in analysis.weekly_change(analysis.weekly_totals(data, 6, today)):
        lines.append(f"Week of {monday:%d %b}: {total:>9,.2f}   {pct:+6.1f}%  {ARROW[trend]}")

    lines += ["", "TOP CATEGORIES THIS MONTH", "-" * 56]
    cats = analysis.category_totals(data, today.year, today.month)
    for name, amt in cats.items():
        share = amt / s["spent"] * 100 if s["spent"] else 0
        lines.append(f"{name:<14}{amt:>10,.2f}  {share:5.1f}%")
    if not cats:
        lines.append("No expenses yet.")
    return "\n".join(lines)
