"""storage.py - saves and loads data (settings + transactions) as JSON."""
import json
import os
from datetime import date

DATA_FILE = os.path.join(os.path.dirname(__file__), "data.json")


def load():
    """Return {'budget': float, 'transactions': [...]}; create defaults if no file."""
    if not os.path.exists(DATA_FILE):
        return {"budget": 0.0, "transactions": []}
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save(data):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def set_budget(data, amount):
    data["budget"] = float(amount)


def add_expense(data, amount, category, on=None, note=""):
    """Add one expense. `on` is a date (defaults to today)."""
    data["transactions"].append({
        "date": (on or date.today()).isoformat(),
        "amount": float(amount),
        "category": category.strip().title(),
        "note": note,
    })
