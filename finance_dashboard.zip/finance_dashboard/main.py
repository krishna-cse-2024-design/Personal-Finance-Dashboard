"""main.py - menu-driven entry point. Run:  python main.py"""
from datetime import date, datetime
import storage, dashboard


def ask_float(prompt):
    while True:
        try:
            v = float(input(prompt))
            if v >= 0:
                return v
        except ValueError:
            pass
        print("Please enter a valid positive number.")


def add_expense(data):
    amount = ask_float("Amount: ")
    category = input("Category (Food, Rent, Travel...): ").strip() or "Other"
    raw = input("Date YYYY-MM-DD (Enter = today): ").strip()
    try:
        on = datetime.strptime(raw, "%Y-%m-%d").date() if raw else date.today()
    except ValueError:
        print("Bad date, using today.")
        on = date.today()
    storage.add_expense(data, amount, category, on)
    storage.save(data)
    print("Saved.")


def main():
    data = storage.load()
    if data["budget"] == 0:
        storage.set_budget(data, ask_float("Set your monthly budget: "))
        storage.save(data)

    while True:
        print("\n1) Show dashboard  2) Add expense  3) Change budget  4) Charts  5) Quit")
        choice = input("Choose: ").strip()
        if choice == "1":
            print("\n" + dashboard.render(data))
        elif choice == "2":
            add_expense(data)
        elif choice == "3":
            storage.set_budget(data, ask_float("New monthly budget: "))
            storage.save(data)
        elif choice == "4":
            try:
                import plots
                plots.show_charts(data)
            except ImportError:
                print("Install matplotlib first:  pip install matplotlib")
        elif choice == "5":
            break


if __name__ == "__main__":
    main()
