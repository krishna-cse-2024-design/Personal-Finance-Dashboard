"""Run once to fill data.json with 6 weeks of sample expenses:  python demo_data.py"""
import random
from datetime import date, timedelta
import storage

random.seed(7)
data = {"budget": 30000.0, "transactions": []}
cats = ["Food", "Travel", "Shopping", "Bills", "Fun"]
for i in range(42):
    day = date.today() - timedelta(days=i)
    for _ in range(random.randint(0, 2)):
        storage.add_expense(data, random.randint(100, 1200), random.choice(cats), day)
storage.save(data)
print("Demo data created.")
