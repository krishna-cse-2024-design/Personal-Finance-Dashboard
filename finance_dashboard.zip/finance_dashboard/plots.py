"""plots.py - optional charts (needs: pip install matplotlib)."""
from datetime import date
import analysis


def show_charts(data, today=None):
    import matplotlib.pyplot as plt   # imported here so the app works without it

    today = today or date.today()
    weeks = analysis.weekly_change(analysis.weekly_totals(data, 8, today))
    labels = [f"{w[0]:%d %b}" for w in weeks]
    totals = [w[1] for w in weeks]
    colors = ["tab:red" if w[4] == "rise" else "tab:green" if w[4] == "fall" else "gray" for w in weeks]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.5))
    ax1.bar(labels, totals, color=colors)
    ax1.set_title("Weekly spending (red = rose, green = fell)")
    ax1.set_ylabel("Amount")

    cats = analysis.category_totals(data, today.year, today.month)
    if cats:
        ax2.pie(cats.values(), labels=cats.keys(), autopct="%1.0f%%")
    ax2.set_title("This month by category")
    plt.tight_layout()
    plt.show()
