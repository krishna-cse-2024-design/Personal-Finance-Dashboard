"""analysis.py - all the maths: budget status, weekly totals, rise/fall."""
import calendar
from collections import defaultdict
from datetime import date, timedelta


def _d(txn):
    return date.fromisoformat(txn["date"])


def month_transactions(data, year, month):
    return [t for t in data["transactions"]
            if _d(t).year == year and _d(t).month == month]


def budget_status(data, today=None):
    """Spent / remaining / daily allowance / projected month-end spend."""
    today = today or date.today()
    days_in_month = calendar.monthrange(today.year, today.month)[1]
    spent = sum(t["amount"] for t in month_transactions(data, today.year, today.month))
    budget = data["budget"]
    days_left = days_in_month - today.day + 1          # includes today
    remaining = budget - spent
    return {
        "budget": budget,
        "spent": spent,
        "remaining": remaining,
        "percent_used": (spent / budget * 100) if budget else 0,
        "safe_per_day": max(remaining, 0) / days_left,
        "projected": spent / today.day * days_in_month,  # pace so far
        "over_budget": spent > budget,
    }


def week_start(d):
    """Monday of the week containing date d."""
    return d - timedelta(days=d.weekday())


def weekly_totals(data, weeks=6, today=None):
    """Return [(monday_date, total_spent), ...] for the last `weeks` weeks, oldest first."""
    today = today or date.today()
    this_monday = week_start(today)
    totals = defaultdict(float)
    for t in data["transactions"]:
        totals[week_start(_d(t))] += t["amount"]
    return [(this_monday - timedelta(weeks=i), totals[this_monday - timedelta(weeks=i)])
            for i in range(weeks - 1, -1, -1)]


def weekly_change(week_data):
    """Add rise/fall info: [(monday, total, change_amount, change_pct, 'rise'|'fall'|'flat')]."""
    out, prev = [], None
    for monday, total in week_data:
        if prev is None:
            out.append((monday, total, 0.0, 0.0, "flat"))
        else:
            diff = total - prev
            pct = (diff / prev * 100) if prev else (100.0 if total else 0.0)
            trend = "rise" if diff > 0 else "fall" if diff < 0 else "flat"
            out.append((monday, total, diff, pct, trend))
        prev = total
    return out


def category_totals(data, year, month):
    totals = defaultdict(float)
    for t in month_transactions(data, year, month):
        totals[t["category"]] += t["amount"]
    return dict(sorted(totals.items(), key=lambda kv: kv[1], reverse=True))
